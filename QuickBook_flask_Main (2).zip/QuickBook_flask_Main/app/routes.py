from flask import Flask, request, jsonify, Blueprint
import hashlib
import hmac
import base64
from app.webhooks import web_hooks
from app.quickbook_api import obtain_access_token, get_transaction_report

rout = Blueprint('app', __name__)

@rout.route('/get_accesstoken', methods=['GET'])
def access_token():
    return obtain_access_token()

@rout.route("/get_transaction_report", methods=['POST'])
def get_transaction():
    values = request.get_json()
    return get_transaction_report(values['access_token'])

@rout.route('/webhooks', methods=['POST'])
def handle_webhook():
    return web_hooks()




def create_app():
    app = Flask(__name__)
    app.register_blueprint(rout)
    return app

app = create_app()

if __name__ == '__main__':
    app.run()





















# from flask import Flask, request, jsonify
# import hashlib
# import hmac
# import base64
# from app.webhooks import web_hooks
# from .__initi__ import rout
# from quickbook_api import obtain_access_token, get_transaction_report
#
#
# @rout.route('/get_accesstoken', methods=['GET'])
# def access_token():
#     return obtain_access_token()
#
#
# @rout.route("/get_transaction_report", methods=['GET'])
# def get_transaction():
#     access_token = ""
#     get_transaction_report(access_token)
#
#
# @rout.route('/webhooks', methods=['POST'])
# def handle_webhook():
#     return web_hooks()