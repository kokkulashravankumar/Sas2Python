from flask import Flask,Blueprint
rout = Blueprint('app', __name__)


def create_app():
    app = Flask(__name__)
    app.register_blueprint(rout)
    return app
