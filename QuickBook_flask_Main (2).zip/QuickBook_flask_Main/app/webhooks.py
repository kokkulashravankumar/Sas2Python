from flask import jsonify, request
import hashlib
import hmac
import base64
import os


def verify_webhook(data, hmac_header):
    digest = hashlib.sha256()
    digest.update(data)
    VERIFIER_TOKEN = os.getenv("VERIFIER_TOKEN")
    calculated_hmac = base64.b64encode(hmac.new(VERIFIER_TOKEN.encode(), data,
                                                digestmod=hashlib.sha256).digest()).decode().strip()
    return calculated_hmac == hmac_header


def web_hooks():
    data = request.get_data()
    verified = verify_webhook(data, request.headers.get('INTUIT_SIGNATURE'))
    v = data.decode('utf-8')
    print("data",data.decode('utf-8'))
    return jsonify({"verified": verified,"data":v})
