import os
import json

import requests


def obtain_access_token():
    """
    Obtain an access token using the provided client ID, client secret, and refresh token.

    Args:
        client_id (str): The client ID for the QuickBooks API.
        client_secret (str): The client secret for the QuickBooks API.
        refresh_token (str): The refresh token associated with the user.

    Returns:
        str: The access token for making API requests.
    """
    client_id = os.getenv('CLIENT_ID')
    client_secret = os.getenv('CLIENT_SECRET')
    refresh_token = os.getenv('refresh_token')
    auth_endpoint = os.getenv("token_endpoint")
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    data = {
        "grant_type": "refresh_token",
        "client_id": client_id,
        "client_secret": client_secret,
        "refresh_token": refresh_token,
    }

    try:
        response = requests.post(auth_endpoint, headers=headers, data=data)
        response.raise_for_status()
        access_token = json.loads(response.text)["access_token"]
        return access_token
    except requests.exceptions.RequestException as e:
        print("Error occurred while obtaining access token:", e)
        return None
    except (KeyError, ValueError) as e:
        print("Invalid response received while obtaining access token:", e)
        return None


def get_transaction_report(access_token):
    """
    Get a transaction report from QuickBooks API using the provided access token, base URL,
    company ID, start date, end date, and minor version.

    Args:
        access_token (str): The access token for making API requests.
        base_url (str): The base URL for the QuickBooks API.
        company_id (str): The company ID for which to retrieve the transaction report.
        start_date (str): The start date for the report in the format 'YYYY-MM-DD'.
        end_date (str): The end date for the report in the format 'YYYY-MM-DD'.
        minor_version (int): The minor version of the API to use.

    Returns:
        str: The response text containing the transaction report.
    """
    base_url = os.getenv("BASE_URL")
    company_id = os.getenv("COMPANY_ID")
    start_date = os.getenv("START_DATE")
    end_date = os.getenv("END_DATE")
    minor_version = os.getenv("MINOR_VERSION")
    url = f"https://{base_url}/v3/company/{company_id}/reports/TransactionList?start_date={start_date}&end_date={end_date}&minorversion={minor_version}"
    auth_header = 'Bearer {0}'.format(access_token)
    headers = {
        'Authorization': auth_header,
        'Accept': 'application/json;charset=UTF-8',
        'Content-type': '*/*'
    }

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        if response.status_code == 200:
            data = response.json()
            print(data)
        else:
            print("Error: Request failed with status code",
                  response.status_code)
        return response.json()
    except requests.exceptions.RequestException as e:
        print("Error occurred while retrieving transaction report:", e)
        return None
